-- =============================================================================
-- ROOT_PATH/executables/LUDUM/LUDUM_41
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DeclareResource("resources")    
