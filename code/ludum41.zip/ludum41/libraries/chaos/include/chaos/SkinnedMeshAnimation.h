#pragma once

#include <chaos/StandardHeaders.h>

namespace chaos
{

class SkinnedMeshAnimation
{



};

}; // namespace chaos
