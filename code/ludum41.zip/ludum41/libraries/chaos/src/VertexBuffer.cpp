﻿#include <chaos/VertexBuffer.h>

namespace chaos
{
	VertexBuffer::VertexBuffer(GLuint in_id) : GPUBuffer(in_id)
	{

	}

}; // namespace chaos
