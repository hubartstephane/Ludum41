﻿#include <chaos/IndexBuffer.h>

namespace chaos
{
	IndexBuffer::IndexBuffer(GLuint in_id) : GPUBuffer(in_id)
	{

	}

}; // namespace chaos
